from plotly.offline import plot
import warnings
warnings.filterwarnings("ignore")
from data_class_unnormalized import S3DIS #ModelNet40, ShapeNetPart,Cifar10,,ModelNet10,Mnist
import numpy as np
import torch

from torch.utils.data.dataloader import DataLoader

import plotly.graph_objects as go
import plotly.express as px
import laspy
from run import create_model
import config
import util.meter as meter


batch = 1 # inference 1 at a time not a prob

def visualise3D(data_loader, net, path):
    # points from 1 block (out of eg 127 office_1) will be stacked into these 1 at a time
    x_stack = np.zeros((1))
    y_stack = np.zeros((1))
    z_stack = np.zeros((1))
    rgb_stack = np.zeros((1))
    
    N=len(data_loader.dataset)
    #n_sample decides which of the blocks in the data loader will be used for stacking and plotting fig
    #1 ensures all the blocks are considered and random has no effect
    n_sample=int(1*len(data_loader.dataset))
    idx_samples=set(np.random.choice(np.arange(N), size=n_sample, replace=False))
    #sa = set(range(25))
    #sb = set(range(48,54))
    #idx_samples = {18,19,38,51,67,85,95,110} # Each .h5 of a room has multiple copies of the same block
    net.eval()
#####################################################################################################################
    for i, sample in enumerate(data_loader): # each sample has 1 block from a room
        
        batch_data=sample[0] # [1 x 8192/2048 x 9] # this is the first return of __getitem__
        batch_labels=sample[1] # # this is the 2nd return of __getitem__
        data_num=sample[2] # this is the 3rd return of __getitem__
        tmp_set=set(np.arange(batch*i,(batch*i)+batch_data.size(0)))
        tmp_set=list(idx_samples.intersection(tmp_set)) # basically select blocks from idx_samples 
        batch_data = batch_data.to(config.device) 
        batch_labels = batch_labels.to(config.device)
        
        raw_out = net.forward(batch_data) 
        pred_choice = raw_out.data.max(2)[1]
        
        ########################### loading the unnormalized xyz from dataloader##########################
        batch_data = sample[3] # this is whats used for ultimate figure
        
        xyz_points=batch_data.cpu().numpy()  
        
        if xyz_points.shape[-1] > 3: #ignore other feats, just take the xyzs
            xyz_points=xyz_points[:,:,:3]
            
        seg_label_pred=pred_choice.cpu().numpy()  
        seg_label_gt=batch_labels.cpu().numpy() 
        
        if len(tmp_set) >0 :
            all_idx=[u- batch*(u//batch) for u in  tmp_set]
            for kk,idx in enumerate(all_idx): # this simply means load the selected blocks
    
                ######################################## FIGURES  ###########################################
                #the predicted labels are mapped to the real coords,because label wont change no matter what coords
                # a particular chair or object has
                x,y,z=xyz_points[idx].T
                rgb=seg_label_pred[idx]
                #x = x - 21.127 # such an op will be necessary in the future in dataloader
                #y = y + 33.713
                x_stack = np.concatenate((x_stack, x), axis = 0)
                y_stack = np.concatenate((y_stack, y), axis = 0)
                z_stack = np.concatenate((z_stack, z), axis = 0)
                
                rgb_stack = np.concatenate((rgb_stack, rgb), axis = 0)

                '''   
                x,y,z=xyz_points[idx].T
                rgb=seg_label_pred[idx]'''
    x = np.delete(x_stack, [0], 0)
    y = np.delete(y_stack, [0], 0)
    z = np.delete(z_stack, [0], 0)
    
    rgb_stack = np.delete(rgb_stack, [0], 0)
              
    fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=1, color=rgb_stack, colorscale='Viridis', opacity=0.8 ) )])
    plot(fig)                   
                            
if __name__ == '__main__': 
    # Dataloader is the most vital part of this code. direct .h5 files are already normalized and so there is
    # no way to get back the original xyz coordinates. THe DL here reads the original txt (the code is extracted
    #from PVCNN prepare data + nmadali_input_diversity_ + inference). Txt files give the chance to save both the normalized
    # and original xyzs. note that now we have +ve xyzs. to have the actual, need to do reverse of this line
    # xyzrgb[:, 0:3] -= np.amin(xyzrgb, axis=0)[0:3]    
    
    valid_set = S3DIS(partition='test', path = config.TEST_FILE_PATH) # set path in config.py
    valid_loader = DataLoader(valid_set, batch_size=config.validation.batch_size, shuffle=False,
                              num_workers=config.num_workers,  drop_last=False)
    net = create_model(config.base_model).to(config.device)
    checkpoint = torch.load('model.pt','cpu')
    net.load_state_dict(checkpoint['best_model_dict']['acc'])
    net.to(config.device)
    
    visualise3D(valid_loader, net, 'pathhhhhhhhhhhhhhhhhh')
    
    
    
    
    
    
    
    
    
'''header = laspy.LasHeader(version="1.2", point_format=0)
outfile = laspy.LasData(header)
outfile.X = x
outfile.Y = y
outfile.Z = z
outfile.classification = rgb_stack
outfile.write('a.las')'''