import torch
from data_class import S3DIS
from torch.utils.data.dataloader import DataLoader
import config
import numpy as np
from run import create_model
import plotly.graph_objects as go
import os
config.process = "TEST"
batch = 1
def main():
    net = create_model(config.base_model).to(config.device)
    TEST_FILE_PATH = 'C:\\Users\\mthossain\\OneDrive - Federation University Australia\\Desktop\\soft study\\Euclideon\\0 Code Base\\NMadali_PointCNN\\test_files.txt'
    valid_set = S3DIS(partition='test', path = TEST_FILE_PATH)
    valid_loader = DataLoader(valid_set, batch_size=batch, shuffle=False,
                                  num_workers=config.num_workers,  drop_last=False)
    
    checkpoint = torch.load('model.pth','cpu')
    net.load_state_dict(checkpoint['best_model_dict']['acc'])
    net.to(config.device)
    evalu(valid_loader, net,html_path="test_output")

def evalu(data_loader, net, calc_confusion_matrix=False, rtn_features=False,html_path="test_output"):
    net.eval()
    N=len(data_loader.dataset)
    n_sample=int(0.05*len(data_loader.dataset))
    idx_samples=set(np.random.choice(np.arange(N), size=n_sample, replace=False))
    
            
    for i, sample in enumerate(data_loader):
        batch_data=sample[0]
        batch_labels=sample[1]
        tmp_set=set(np.arange(batch*i,(batch*i)+batch_data.size(0)))
        tmp_set=list(idx_samples.intersection(tmp_set))
        batch_data = batch_data.to(config.device) 
        batch_labels = batch_labels.to(config.device)
        
        raw_out = net.forward(batch_data) 
        pred_choice = raw_out.data.max(2)[1]
        xyz_points=batch_data.cpu().numpy()  
        if xyz_points.shape[-1] > 3:
            xyz_points=xyz_points[:,:,:3]
        seg_label_pred=pred_choice.cpu().numpy()  
        seg_label_gt=batch_labels.cpu().numpy()  
        if len(tmp_set) >0 :
            all_idx=[u- batch*(u//batch) for u in  tmp_set]
            for kk,idx in enumerate(all_idx):
    
                ######################################## FIGURES  ###########################################
                x,y,z=xyz_points[idx].T
                rgb=seg_label_gt[idx]
                fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=2, color=rgb, colorscale='Viridis', opacity=0.8 ) )])
                fig.write_html(os.path.join(html_path,"file"+str(tmp_set[kk])+"_gt.html"))
                
    
              
    
                x,y,z=xyz_points[idx].T
                rgb=seg_label_pred[idx]
    
                fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=2, color=rgb, colorscale='Viridis', opacity=0.8 ) )])
                fig.write_html(os.path.join(html_path,"file"+str(tmp_set[kk])+"_pred.html"))
    
    
if __name__ == '__main__':
    main()
