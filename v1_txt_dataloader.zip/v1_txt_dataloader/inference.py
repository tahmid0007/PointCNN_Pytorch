import torch
from data_class import S3DIS
from torch.utils.data.dataloader import DataLoader
import config
import numpy as np
from run import create_model,calculate_shape_IoU,plot_conf_matrix
import plotly.graph_objects as go
import os
import torch.nn as nn
import util.meter as meter
import sklearn.metrics as metrics
       
cats = ['clutter','ceiling','floor','wall','beam','column','door','window','table','chair','sofa','bookcase','board']

config.process = "TEST"
batch = 1
criterion = nn.CrossEntropyLoss()
def main():
    net = create_model(config.base_model).to(config.device)
    TEST_FILE_PATH = 'C:\\Users\\mthossain\\OneDrive - Federation University Australia\\Desktop\\soft study\\Euclideon\\0 Code Base\\NMadali_PointCNN\\test_files.txt'
    valid_set = S3DIS(partition='test', path = TEST_FILE_PATH)
    valid_loader = DataLoader(valid_set, batch_size=batch, shuffle=False,
                                  num_workers=config.num_workers,  drop_last=False)
    
    checkpoint = torch.load('model.pth','cpu')
    net.load_state_dict(checkpoint['best_model_dict']['acc'])
    net.to(config.device)
    evalu(valid_loader, net,html_path="test_output")

def evalu(data_loader, net, calc_confusion_matrix=False, rtn_features=False,html_path="test_output"):
    net.eval()
    loss_meter = meter.AverageValueMeter()
    acc_meter = meter.ClassErrorMeter(topk=[1, 5], accuracy=True)
    avg_acc_meter = meter.AverageValueMeter()
    Iou_meter = meter.AverageValueMeter()
    Iou_meter = meter.AverageValueMeter()
    
    
    N=len(data_loader.dataset)
    n_sample=int(0.05*len(data_loader.dataset))
    idx_samples=set(np.random.choice(np.arange(N), size=n_sample, replace=False))
    
            
    for i, sample in enumerate(data_loader):
        batch_data=sample[0]
        batch_labels=sample[1]
        tmp_set=set(np.arange(batch*i,(batch*i)+batch_data.size(0)))
        tmp_set=list(idx_samples.intersection(tmp_set))
        batch_data = batch_data.to(config.device) 
        batch_labels = batch_labels.to(config.device)
        
        raw_out = net.forward(batch_data) 
        pred_choice = raw_out.data.max(2)[1]
        xyz_points=batch_data.cpu().numpy()  
        if xyz_points.shape[-1] > 3:
            xyz_points=xyz_points[:,:,:3]
        seg_label_pred=pred_choice.cpu().numpy()  
        seg_label_gt=batch_labels.cpu().numpy()  
        if len(tmp_set) >0 :
            all_idx=[u- batch*(u//batch) for u in  tmp_set]
            for kk,idx in enumerate(all_idx):
    
                ######################################## FIGURES  ###########################################
                x,y,z=xyz_points[idx].T
                rgb=seg_label_gt[idx]
                fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=2, color=rgb, colorscale='Viridis', opacity=0.8 ) )])
                fig.write_html(os.path.join(html_path,"file"+str(tmp_set[kk])+"_gt.html"))
                
    
              
    
                x,y,z=xyz_points[idx].T
                rgb=seg_label_pred[idx]
    
                fig = go.Figure(data=[go.Scatter3d( x=x, y=y, z=z, mode='markers', marker=dict( size=2, color=rgb, colorscale='Viridis', opacity=0.8 ) )])
                fig.write_html(os.path.join(html_path,"file"+str(tmp_set[kk])+"_pred.html"))
    
        raw_out = raw_out.view(-1, raw_out.shape[-1])
        loss=criterion(raw_out, batch_labels.view(-1).long())

    loss_meter.add(loss.item())
    acc_meter.add(raw_out.detach(),  batch_labels.view(-1).long().detach())
    
    seg_np = batch_labels.cpu().numpy()                
    pred_np = pred_choice.detach().cpu().numpy()
    
    
    avg_acc_meter.add( metrics.balanced_accuracy_score(seg_np.reshape(-1), pred_np.reshape(-1)))
    Iou_meter.add(np.mean(calculate_shape_IoU(pred_np, seg_np, None)))
    train_acc = acc_meter.value(1) # name only train ashole val
    avg_per_class_acc = avg_acc_meter.value()[0]
    train_ious = Iou_meter.value()[0]    
    outstr = '[ Validation summary ] validation_loss: %.6f, validation_acc: %.6f, avg_per_class_acc: %.6f, val_ious: %.6f' % (loss_meter.value()[0] , train_acc, avg_per_class_acc, np.mean(train_ious))
    print(outstr)
    rst = loss_meter.value()[0],train_acc,avg_per_class_acc, np.mean(train_ious)
    
    confusion_matrix_meter = None
    num_classes = 13
    confusion_matrix_meter = meter.ConfusionMeter(num_classes, normalized=True)
    with torch.no_grad():
        confusion_matrix_meter.add(raw_out, target=batch_labels)
        conf_matrix = confusion_matrix_meter.value()
        plot_conf_matrix(cats, conf_matrix,
                                save_file='{}conf_matrix.pdf'.format(config.result_sub_folder))
    
    
    return rst
                    
if __name__ == '__main__':
    main()
