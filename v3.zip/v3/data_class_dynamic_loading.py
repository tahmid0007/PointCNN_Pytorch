from tqdm import tqdm
import random
import os
import h5py
import numpy as np
import glob
from torch.utils.data import Dataset
from dataset import pointfly as pf

def load_data_s3dis_dynamic_loading(file):

    points = []
    point_nums = []
    labels_seg = []
    
    #for h5_name in file: # traverse each .h5 file
    data = h5py.File(file, 'r+')
    xyz=data['data'][:].astype(np.float32)
    fts=data['label_seg'][:].astype(np.int64)
    tmp1=[]
    tmp2=[]
    for i in range(xyz.shape[0]):
        pc=xyz[i]
        choices = np.random.choice(pc.shape[0], 2048, replace=False) # DS 2048 from 8192 pts

        tmp1.append(pc[choices,:])
        tmp2.append((fts[i])[choices])
    points.append(np.array(tmp1,dtype=np.float32).reshape((xyz.shape[0],2048,9)))
    labels_seg.append(np.array(tmp2,dtype=np.int64).reshape((xyz.shape[0],2048)))

    for u in  data['data'][...].astype(np.int64):
        point_nums.append(2048)
        

    return (np.concatenate(points, axis=0), None, np.array(point_nums).reshape(-1), np.concatenate(labels_seg, axis=0), None)

# This is not working bcs dataloader expects the no of 1mx1m in a .h5 file, not no of h5 files (can be other/additional errors)
# might need to have a separate txt file with no of such blocks in each line of that file
################## Main Data Loader (all h5 loaded at once into self.points)  ###########
class S3DIS_dynamic_loading(Dataset):
    def __init__(self, partition='train',transforms=None, path = None):
        super().__init__()
        self.filelist = path
        self.file = [line.strip() for line in open(self.filelist)]
        self.points, _, self.point_nums, self.labels_seg, _  = load_data_s3dis_dynamic_loading(self.file[0])  

    def __getitem__(self, index):
        
        #self.points, _, self.point_nums, self.labels_seg, _  = load_data_s3dis_dynamic_loading(self.file[index])  
        points = []
        point_nums = []
        labels_seg = []
        #for idx in index:
        file = self.file[index]
        data = h5py.File(file, 'r+')
        xyz=data['data'][:].astype(np.float32)
        fts=data['label_seg'][:].astype(np.int64)
        tmp1=[]
        tmp2=[]
        for i in range(xyz.shape[0]):
            pc=xyz[i]
            choices = np.random.choice(pc.shape[0], 2048, replace=False) # DS 2048 from 8192 pts
    
            tmp1.append(pc[choices,:])
            tmp2.append((fts[i])[choices])
        points.append(np.array(tmp1,dtype=np.float32).reshape((xyz.shape[0],2048,9)))
        labels_seg.append(np.array(tmp2,dtype=np.int64).reshape((xyz.shape[0],2048)))
    
        for u in  data['data'][...].astype(np.int64):
            point_nums.append(2048)
                    
        self.points = (np.concatenate(points, axis=0))
        self.point_nums = np.array(point_nums).reshape(-1)
        self.labels_seg = np.concatenate(labels_seg, axis=0)
        self.points=pf.global_norm(self.points)
        
        return self.points, self.labels_seg, self.point_nums,-1

        

    def __len__(self):
        return self.points.shape[0]