data/s3dis_sample/office_1/half_0.h5
data/s3dis_sample/office_2/zero_0.h5
data/s3dis_sample/office_2/half_0.h5
data/s3dis_sample/office_3/zero_0.h5
data/s3dis_sample/office_3/half_0.h5
data/s3dis_sample/office_4/zero_0.h5
data/s3dis_sample/office_4/half_0.h5
data/s3dis_sample/office_5/zero_0.h5
data/s3dis_sample/office_5/half_0.h5
data/s3dis_sample/office_6/zero_0.h5
data/s3dis_sample/office_6/half_0.h5
data/s3dis_sample/office_7/zero_0.h5
data/s3dis_sample/office_7/half_0.h5
data/s3dis_sample/office_8/zero_0.h5
data/s3dis_sample/office_8/half_0.h5
data/s3dis_sample/office_9/zero_0.h5
data/s3dis_sample/office_9/half_0.h5
data/s3dis_sample/office_10/zero_0.h5
data/s3dis_sample/office_10/half_0.h5
data/s3dis_sample/office_11/zero_0.h5
data/s3dis_sample/office_11/half_0.h5
data/s3dis_sample/office_12/zero_0.h5
data/s3dis_sample/office_12/half_0.h5
data/s3dis_sample/office_13/zero_0.h5
data/s3dis_sample/office_13/half_0.h5
data/s3dis_sample/office_14/zero_0.h5
data/s3dis_sample/office_14/half_0.h5
data/s3dis_sample/office_15/zero_0.h5
data/s3dis_sample/office_15/half_0.h5
data/s3dis_sample/office_16/zero_0.h5
data/s3dis_sample/office_16/half_0.h5
data/s3dis_sample/office_17/zero_0.h5
data/s3dis_sample/office_17/half_0.h5
data/s3dis_sample/office_18/zero_0.h5
data/s3dis_sample/office_18/half_0.h5
data/s3dis_sample/office_19/zero_0.h5
data/s3dis_sample/office_19/half_0.h5
data/s3dis_sample/office_20/zero_0.h5
data/s3dis_sample/office_20/half_0.h5
data/s3dis_sample/office_21/zero_0.h5
data/s3dis_sample/office_21/half_0.h5
data/s3dis_sample/office_22/zero_0.h5
data/s3dis_sample/office_22/half_0.h5
data/s3dis_sample/office_23/zero_0.h5
data/s3dis_sample/office_23/half_0.h5
data/s3dis_sample/office_24/zero_0.h5
data/s3dis_sample/office_24/half_0.h5
data/s3dis_sample/office_25/zero_0.h5
data/s3dis_sample/office_25/half_0.h5
data/s3dis_sample/office_26/zero_0.h5
data/s3dis_sample/office_26/half_0.h5
data/s3dis_sample/office_27/zero_0.h5
data/s3dis_sample/office_27/half_0.h5
data/s3dis_sample/hallway_1/zero_0.h5
data/s3dis_sample/hallway_1/half_0.h5
data/s3dis_sample/hallway_2/zero_0.h5
data/s3dis_sample/hallway_2/half_0.h5
data/s3dis_sample/hallway_3/zero_0.h5
data/s3dis_sample/hallway_3/half_0.h5
data/s3dis_sample/hallway_4/zero_0.h5
data/s3dis_sample/hallway_4/half_0.h5
data/s3dis_sample/hallway_5/zero_0.h5
data/s3dis_sample/hallway_5/half_0.h5
data/s3dis_sample/hallway_6/zero_0.h5
data/s3dis_sample/hallway_6/half_0.h5
data/s3dis_sample/hallway_7/zero_0.h5
data/s3dis_sample/hallway_7/half_0.h5
data/s3dis_sample/hallway_8/zero_0.h5
data/s3dis_sample/hallway_8/half_0.h5

test
data/s3dis_sample/office_28/half_0.h5
data/s3dis_sample/conferenceRoom_1/zero_0.h5
data/s3dis_sample/conferenceRoom_1/half_0.h5
data/s3dis_sample/copyRoom_1/zero_0.h5
data/s3dis_sample/copyRoom_1/half_0.h5
data/s3dis_sample/pantry_1/zero_0.h5
data/s3dis_sample/pantry_1/half_0.h5
data/s3dis_sample/hallway_1/zero_0.h5
data/s3dis_sample/hallway_1/half_0.h5
data/s3dis_sample/WC_1/zero_0.h5
data/s3dis_sample/WC_1/half_0.h5

C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/WC_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/WC_1/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/conferenceRoom_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/conferenceRoom_1/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/conferenceRoom_2/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/conferenceRoom_2/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/copyRoom_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/copyRoom_1/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_1/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_2/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_2/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_3/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_3/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_4/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_4/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_5/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_5/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_6/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_6/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_7/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_7/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_8/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/hallway_8/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_1/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_10/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_10/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_11/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_11/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_12/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_12/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_13/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_13/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_14/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_14/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_15/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_15/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_16/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_16/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_17/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_17/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_18/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_18/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_19/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_19/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_2/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_2/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_20/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_20/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_21/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_21/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_22/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_22/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_23/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_23/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_24/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_24/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_25/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_25/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_26/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_26/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_27/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_27/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_28/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_28/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_29/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_29/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_3/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_3/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_30/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_30/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_31/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_31/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_4/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_4/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_5/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_5/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_6/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_6/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_7/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_7/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_8/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_8/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_9/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/office_9/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/pantry_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/pantry_1/half_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/WC_1/zero_0.h5
C:/Users/mthossain/OneDrive - Federation University Australia/Desktop/soft study/Euclideon/PVCNN/data/s3dis/pointcnn/Area_1/WC_1/half_0.h5
